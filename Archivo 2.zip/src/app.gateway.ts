import {
  SubscribeMessage,
  WebSocketGateway,
  OnGatewayInit,
  WebSocketServer,
  OnGatewayConnection,
  OnGatewayDisconnect,
} from '@nestjs/websockets';
import { Logger } from '@nestjs/common';
import { Socket, Server } from 'socket.io';
@WebSocketGateway(3001, {
  cors: {
    origin: ['http://localhost:4200', '*'],
    methods: ['GET', 'POST', 'OPTIONS', 'PUT', 'PATCH', 'DELETE'],
    allowedHeaders: ['X-Requested-With', 'content-type'],
    credentials: true,
  },
})
export class AppGateway
  implements OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect
{
  @WebSocketServer() server: Server;
  private logger: Logger = new Logger('AppGateway');

  @SubscribeMessage('message')
  handleMessage(client: Socket, payload: string): void {
    this.server.emit('msgToClient', payload);
  }

  @SubscribeMessage('join')
  handleJoin(client: Socket, payload: string): void {
    console.log('User joined');
    // this.server.emit('msgToClient', payload);
  }

  afterInit(server: Server) {
    this.logger.log('Init');
  }

  handleDisconnect(client: Socket) {
    this.logger.log(`Client disconnected: ${client.id}`);
  }

  handleConnection(client: Socket, ...args: any[]) {
    // lock (ParticipantsConnectionLock)
    //     {
    //         AllConnectedParticipants.Add(new ParticipantResponseViewModel()
    //         {
    //             Metadata = new ParticipantMetadataViewModel()
    //             {
    //                 TotalUnreadMessages = 0
    //             },
    //             Participant = new ChatParticipantViewModel()
    //             {
    //                 DisplayName = userName,
    //                 Id = Context.ConnectionId
    //             }
    //         });

    //         // This will be used as the user's unique ID to be used on ng-chat as the connected user.
    //         // You should most likely use another ID on your application
    //         Clients.Caller.SendAsync("generatedUserId", Context.ConnectionId);

    //         Clients.All.SendAsync("friendsListChanged", AllConnectedParticipants);
    //     }
    this.logger.log(`Client connected: ${client.id}`);
  }
}
