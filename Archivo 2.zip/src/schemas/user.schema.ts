import { Prop, raw, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type UserDocument = User & Document;

@Schema()
export class User {
  @Prop(
    raw({
      id: { type: String },
      displayName: { type: String },
      lastName: { type: String },
      status: { type: String },
      avatar: { type: String },
      participantType: { type: String },
      chattingTo: { type: String },
    }),
  )
  participant: Record<string, any>;
}

export const UserSchema = SchemaFactory.createForClass(User);
