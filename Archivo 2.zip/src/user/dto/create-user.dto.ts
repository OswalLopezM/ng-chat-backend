import { ApiProperty } from "@nestjs/swagger";

export class CreateUserDto {
    @ApiProperty()
    participant: {
        id?: string;
        displayName?: string;
        status?: number;
        avatar?: string;
        participantType?: number;
        chattingTo?: any[];
    };
}