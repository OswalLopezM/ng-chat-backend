import { Injectable } from '@nestjs/common';
import { User, UserDocument } from 'src/schemas/user.schema';
import { CreateUserDto } from './dto/create-user.dto';
import { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';

@Injectable()
export class UserService {
  constructor(@InjectModel(User.name) private userModel: Model<UserDocument>) {}

    async create(createMessageDto: CreateUserDto): Promise<User> {
        const createdMessage = new this.userModel(createMessageDto);
        return createdMessage.save();
    }

    async findAll(): Promise<User[]> {
        return this.userModel.find().exec();
    }
}
